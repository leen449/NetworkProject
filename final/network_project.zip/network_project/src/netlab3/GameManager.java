package netlab3;

import java.io.File;
import java.util.*;
import javax.swing.JOptionPane;

public class GameManager {
    private static List<File> remainingAudioFiles = new ArrayList<>();
    private static int currentRound = 0;
private static final int MAX_ROUNDS = 5;
    private static final String AUDIO_FOLDER = "audio/";
    private static final Map<String, Integer> scores = new HashMap<>();
    private static String currentAnswer = "";
    private static boolean acceptingAnswers = false;
    private static int roundId = 0; // tracks current round ID


  private static Map<String, String> loadAnswerMap() {
    Map<String, String> answerMap = new HashMap<>();
    File file = new File("audio/answers.txt");
    if (!file.exists()) {
        System.out.println("⚠️ answers.txt not found at: " + file.getAbsolutePath());
        return answerMap;
    }

    try (Scanner scanner = new Scanner(file, "UTF-8")) {
        while (scanner.hasNextLine()) {
            String[] parts = scanner.nextLine().split("=", 2);
            if (parts.length == 2) {
                answerMap.put(parts[0].trim(), parts[1].trim());
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return answerMap;
}


public static void startRound(List<NewClient> players) {
    if (currentRound >= MAX_ROUNDS) {
        endFullGame();
        return;
    }

    currentRound++;
    roundId++; // 🔐 Update round ID
    final int thisRound = roundId; // 🔐 Capture this round's ID

    // ✅ Load remaining audio files only once (or if all used)
    if (remainingAudioFiles.isEmpty()) {
        File audioDir = new File("audio");
        File[] files = audioDir.listFiles((dir, name) -> name.toLowerCase().endsWith(".mp3"));
        if (files == null || files.length == 0) {
            System.out.println("No audio files found.");
            return;
        }

        remainingAudioFiles = new ArrayList<>(Arrays.asList(files));
        Collections.shuffle(remainingAudioFiles); // random order
    }

    // ✅ End game if no more files to use
    if (remainingAudioFiles.isEmpty()) {
        endFullGame();
        return;
    }

    // ✅ Pick and remove one file for this round
    File selected = remainingAudioFiles.remove(0);

    Map<String, String> answerMap = loadAnswerMap();
    String fileName = selected.getName();
    currentAnswer = answerMap.getOrDefault(fileName, "").trim();
    acceptingAnswers = true;

    System.out.println("Selected audio file: " + fileName);
    System.out.println("Correct answer is: [" + currentAnswer + "]");

    for (NewClient player : players) {
        player.send("ROUND_INFO:" + currentRound + "/" + MAX_ROUNDS);
        player.send("PLAY_AUDIO:" + fileName);
        player.send("START_TIMER:30");
    }

    // ⏱ 30 second round timer — ONLY runs if still same round
    new Timer().schedule(new TimerTask() {
        public void run() {
            if (thisRound == roundId && acceptingAnswers) {
                acceptingAnswers = false;
                announceNoWinner();
                System.out.println("Timer expired. No winner. Proceeding to next round.");
            }
        }
    }, 30000);
}
    


private static void endFullGame() {
    int highest = scores.values().stream().max(Integer::compareTo).orElse(0);

    List<String> topPlayers = new ArrayList<>();
    for (Map.Entry<String, Integer> entry : scores.entrySet()) {
        if (entry.getValue() == highest) {
            topPlayers.add(entry.getKey());
        }
    }

    String winnerMessage;
    if (topPlayers.size() > 1) {
        winnerMessage = "تعادل بين: " + String.join(", ", topPlayers);
    } else if (topPlayers.size() == 1) {
        winnerMessage = " " + topPlayers.get(0);
    } else {
        winnerMessage = "لا يوجد فائز";
    }

    for (NewClient client : NewServer.getClients()) {
        client.send("GAME_OVER:" + winnerMessage);
    }

    currentRound = 0;
    scores.clear();
    remainingAudioFiles.clear();
}



public static void submitAnswer(NewClient player, String answer) {
    if (!acceptingAnswers) return;

    System.out.println(player.getName() + " submitted: [" + answer + "]");
    System.out.println("Comparing to: [" + currentAnswer + "]");

    if (answer.trim().equalsIgnoreCase(currentAnswer)) {
        acceptingAnswers = false;

        // Update the correct player's score
        String name = player.getName();
        int newScore = scores.getOrDefault(name, 0) + 1;
        scores.put(name, newScore);

        // Announce winner to all players
        for (NewClient c : player.getClients()) {
            c.send("WINNER:" + name);
            c.send("DISABLE_INPUT");
        }

        // Send updated scores to all
        broadcastScores(player.getClients());

        // Start next round after short delay
        prepareNextRound();

    } else {
        // Let the answering player know it's wrong
        player.send("WRONG_ANSWER");
    }
}


    public static void broadcastScores(List<NewClient> clients) {
        StringBuilder scoreData = new StringBuilder("SCORES:");
        for (Map.Entry<String, Integer> entry : scores.entrySet()) {
            scoreData.append(entry.getKey()).append("=").append(entry.getValue()).append(",");
        }

        for (NewClient client : clients) {
            client.send(scoreData.toString());
        }
    }
    
    
   private static void announceNoWinner() {
    acceptingAnswers = false; // ⛔️ stop the round from accepting new answers

    for (NewClient client : NewServer.getClients()) {
        client.send("NO_WINNER");
    }

    prepareNextRound();
    System.out.println("announceNoWinner called at: " + System.currentTimeMillis());
// ⏭ wait 5s, then start the next round
}


private static void prepareNextRound() {
    new Timer().schedule(new TimerTask() {
        public void run() {
            startRound(NewServer.getClients());
        }
    }, 5000); // Wait 5 seconds before next round starts
}


}
