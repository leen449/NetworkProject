
package netlab3;
import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import javazoom.jl.player.Player;
import java.io.FileInputStream;


public class mainGui extends javax.swing.JFrame {
    private int timeLeft = 0;
    private Timer swingTimer;
    private String currentAudioFile = "";
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    private String playerName;
    
    public mainGui() {
        initComponents();
        jTabbedPane1.setUI(null); // لإخفاء التبويبات
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel3 = new javax.swing.JPanel();
        nameField = new javax.swing.JTextField();
        connectButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        playerListArea = new javax.swing.JTextArea();
        joinGameButton = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        waitingListArea = new javax.swing.JTextArea();
        jLabel3 = new javax.swing.JLabel();
        GamePanel = new javax.swing.JPanel();
        playAudioButton = new javax.swing.JButton();
        answerField = new javax.swing.JTextField();
        submitButton = new javax.swing.JButton();
        scoreArea = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        timerLabel = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel3.add(nameField, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 150, 215, -1));

        connectButton.setText("اتصل");
        connectButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                connectButtonActionPerformed(evt);
            }
        });
        jPanel3.add(connectButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 140, -1, -1));

        playerListArea.setColumns(20);
        playerListArea.setRows(5);
        jScrollPane1.setViewportView(playerListArea);

        jPanel3.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 190, 271, 170));

        joinGameButton.setText("انضم الى اللعبة");
        joinGameButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                joinGameButtonActionPerformed(evt);
            }
        });
        jPanel3.add(joinGameButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 390, 395, -1));

        jLabel5.setBackground(new java.awt.Color(255, 255, 255));
        jLabel5.setFont(new java.awt.Font("Arial", 1, 36)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("نطقها وعرفنا");
        jPanel3.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 20, 160, 60));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/netlab3/image.jpg"))); // NOI18N
        jLabel2.setText("jLabel2");
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, -50, 590, 550));

        jTabbedPane1.addTab("tab1", jPanel3);

        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setBackground(new java.awt.Color(0, 0, 0));
        jLabel1.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("قائمة الانتظار");
        jPanel4.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 10, -1, 30));

        waitingListArea.setColumns(20);
        waitingListArea.setRows(5);
        jScrollPane2.setViewportView(waitingListArea);

        jPanel4.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(21, 45, 239, 166));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/netlab3/image.jpg"))); // NOI18N
        jLabel3.setText("jLabel3");
        jPanel4.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -10, 580, 510));

        jTabbedPane1.addTab("tab2", jPanel4);

        GamePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        playAudioButton.setText("شغل الصوت");
        playAudioButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                playAudioButtonActionPerformed(evt);
            }
        });
        GamePanel.add(playAudioButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 310, -1, -1));

        answerField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                answerFieldActionPerformed(evt);
            }
        });
        GamePanel.add(answerField, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 380, 260, -1));

        submitButton.setText("📤 ارسل الاجابة");
        submitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitButtonActionPerformed(evt);
            }
        });
        GamePanel.add(submitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 370, -1, -1));

        jTextArea1.setEditable(false);
        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jTextArea1.setRows(5);
        scoreArea.setViewportView(jTextArea1);

        GamePanel.add(scoreArea, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, 160));

        timerLabel.setBackground(new java.awt.Color(255, 255, 255));
        timerLabel.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        timerLabel.setForeground(new java.awt.Color(255, 255, 255));
        timerLabel.setText("الوقت : 30");
        GamePanel.add(timerLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 40, 120, 30));

        jLabel6.setBackground(new java.awt.Color(0, 0, 0));
        jLabel6.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("<html>الخيارات : <br>نجدية<br>جنوبية<br>شمالية<br>حجازية<br>شرقية</html>");
        GamePanel.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 90, 100, 170));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/netlab3/image.jpg"))); // NOI18N
        jLabel4.setText("تسن");
        GamePanel.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 580, 500));

        jTabbedPane1.addTab("tab3", GamePanel);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void connectButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_connectButtonActionPerformed
connectToServer();        // TODO add your handling code here:
    }//GEN-LAST:event_connectButtonActionPerformed

    private void joinGameButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_joinGameButtonActionPerformed
joinGame();        // TODO add your handling code here:
    }//GEN-LAST:event_joinGameButtonActionPerformed

    private void playAudioButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_playAudioButtonActionPerformed
    playAudio(currentAudioFile);       // TODO add your handling code here:
    }//GEN-LAST:event_playAudioButtonActionPerformed

    private void submitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitButtonActionPerformed
sendAnswer();        // TODO add your handling code here:
    }//GEN-LAST:event_submitButtonActionPerformed

    private void answerFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_answerFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_answerFieldActionPerformed

    /**
     * @param args the command line arguments
     */
    private void connectToServer() {
        try {
            socket = new Socket("192.168.15.1", 9090); // غيّر IP إذا لزم الأمر
            out = new PrintWriter(socket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            playerName = nameField.getText();
            if (playerName.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter a name.");
                return;
            }

            out.println(playerName);
            connectButton.setEnabled(false);
            joinGameButton.setEnabled(true);

            new Thread(this::listenToServer).start();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Failed to connect to server.");
        }
    }
    
     private void disconnectFromServer() {
        if (out != null) {
            out.println("DISCONNECT");
        }
        System.exit(0);
    }

    private void listenToServer() {
        try {
            String message;
            while ((message = in.readLine()) != null) {
                if (message.startsWith("PLAYER_LIST:")) {
                    updatePlayerList(message.substring(12));
                } else if (message.startsWith("WAITING_LIST:")) {
                    updateWaitingList(message.substring(13));
  
                }else if (message.equals("GAME_START")) {
    JOptionPane.showMessageDialog(this, "اللعبة بدأت!");
        playBackgroundMusic();
    jTabbedPane1.setSelectedIndex(2); // show game panel
    // do not break — wait for PLAY_AUDIO
} else if (message.startsWith("PLAY_AUDIO:")) {
        jTabbedPane1.setSelectedIndex(2); // show game panel
    currentAudioFile = message.substring(11);
    
} else if (message.startsWith("SCORES:")) {
    updateScores(message.substring(7));
}
         else if (message.startsWith("WINNER:")) {
    if (swingTimer != null) {
        swingTimer.stop(); // ⛔ stop the countdown UI
    }
    timerLabel.setText("الوقت: 0");
    String winner = message.substring(7);
    JOptionPane.showMessageDialog(this, "الفائز هو: " + winner);
}
else if (message.equals("NO_WINNER")) {
    if (swingTimer != null) swingTimer.stop();

    new Timer(1000, e -> {
        JOptionPane.showMessageDialog(this, "انتهى الوقت، لم يجب أحد بشكل صحيح.");
    }).setRepeats(false);
}

else if (message.startsWith("GAME_OVER:")) {
    String winner = message.substring(10);
    JOptionPane.showMessageDialog(this, "انتهت اللعبة! الفائز هو: " + winner);
    jTabbedPane1.setSelectedIndex(0); // return to welcome tab
}

else if (message.startsWith("ROUND_INFO:")) {
    JOptionPane.showMessageDialog(this, "الجولة " + message.substring(11));
}
                else if (message.equals("DISABLE_INPUT")) {
    submitButton.setEnabled(false);
}
else if (message.startsWith("START_TIMER:")) {
    int seconds = Integer.parseInt(message.substring(12));
    startTimer(seconds);
}else if (message.equals("WRONG_ANSWER")) {
    JOptionPane.showMessageDialog(this, "إجابة خاطئة، حاول مرة أخرى.");
}

            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Connection lost.");
        }
    }
    
    private void updateScores(String scoreData) {
    SwingUtilities.invokeLater(() -> {
        String[] entries = scoreData.split(",");
        StringBuilder sb = new StringBuilder("النتائج:\n");
        for (String entry : entries) {
            if (entry.contains("=")) {
                String[] parts = entry.split("=");
                sb.append(parts[0]).append(": ").append(parts[1]).append("\n");
            }
        }
        jTextArea1.setText(sb.toString());
    });
    SwingUtilities.invokeLater(() -> {
    answerField.setText("");
submitButton.setEnabled(true);
answerField.setText(""); // optional: clear field too
});

}
    
   private Thread musicThread;

private void playBackgroundMusic() {
    if (musicThread != null && musicThread.isAlive()) {
        return; // already playing
    }

    musicThread = new Thread(() -> {
        try {
            while (true) {
                FileInputStream fis = new FileInputStream("background/music.mp3");
                Player player = new Player(fis);
                player.play(); // blocks until done
                fis.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "فشل في تشغيل موسيقى الخلفية");
        }
    });
    musicThread.start();
}
 
    private void startTimer(int seconds) {
    timeLeft = seconds;

    if (swingTimer != null) {
        swingTimer.stop();
    }

    swingTimer = new Timer(1000, e -> {
        timeLeft--;
        timerLabel.setText("الوقت: " + timeLeft);
        if (timeLeft <= 0) {
            swingTimer.stop();
        }
    });

    timerLabel.setText("الوقت: " + timeLeft);
    swingTimer.start();
}

 private void playAudio(String filename) {
    new Thread(() -> {
        try {
            String fullPath = "audio/" + filename;
            System.out.println("Trying to play: " + fullPath); // ✅
            System.out.println("Trying to play: audio/" + filename);

            FileInputStream fis = new FileInputStream(fullPath);
            Player player = new Player(fis);
            player.play();
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "فشل في تشغيل الصوت: " + filename);
        }
    }).start();
}

    
    private void sendAnswer() {
    String guess = answerField.getText().trim();
    if (!guess.isEmpty()) {
        out.println("ANSWER:" + guess);
    }
}
    

    private void updatePlayerList(String players) {
        SwingUtilities.invokeLater(() -> {
            playerListArea.setText("Connected Players:\n" + players.replace(",", "\n"));
        });
    }

    private void updateWaitingList(String players) {
        SwingUtilities.invokeLater(() -> {
            waitingListArea.setText("Waiting Room Players:\n" + players.replace(",", "\n"));
        });
    }

    private void joinGame() {
        out.println("JOIN_GAME");
        jTabbedPane1.setSelectedIndex(1);
    }
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(mainGui.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(mainGui.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(mainGui.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(mainGui.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new mainGui().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel GamePanel;
    private javax.swing.JTextField answerField;
    private javax.swing.JButton connectButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JButton joinGameButton;
    private javax.swing.JTextField nameField;
    private javax.swing.JButton playAudioButton;
    private javax.swing.JTextArea playerListArea;
    private javax.swing.JScrollPane scoreArea;
    private javax.swing.JButton submitButton;
    private javax.swing.JLabel timerLabel;
    private javax.swing.JTextArea waitingListArea;
    // End of variables declaration//GEN-END:variables
}
